package ma.rumuz.almalafat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF16324F)
private val Teal = Color(0xFF167D83)
private val Pale = Color(0xFFF3F6F8)
private data class FileCode(val code: String, val name: String, val category: String, val level: String = "")

// Starter dataset transcribed from the public reference page; verify before official use.
private val codes = listOf(
    FileCode("1101", "الاستعجالي", "مؤسسة الرئيس وغرفة المشورة"),
    FileCode("1102", "الأمر بالأداء", "مؤسسة الرئيس وغرفة المشورة"),
    FileCode("1103", "الحجز التحفظي", "مؤسسة الرئيس وغرفة المشورة"),
    FileCode("1104", "الحجز لدى الغير", "مؤسسة الرئيس وغرفة المشورة"),
    FileCode("1121", "صعوبة التنفيذ", "مؤسسة الرئيس وغرفة المشورة"),
    FileCode("1123", "إيقاف التنفيذ", "مؤسسة الرئيس وغرفة المشورة"),
    FileCode("1201", "المدني المتنوع", "المدني", "ابتدائي"),
    FileCode("1203", "التجاري", "المدني", "ابتدائي"),
    FileCode("1204", "الإداري", "المدني", "ابتدائي"),
    FileCode("1207", "تذييل بالصيغة التنفيذية", "المدني", "ابتدائي"),
    FileCode("1220", "الأوامر بالأداء المستأنفة", "المدني", "استئنافي"),
    FileCode("1301", "أداء واجبات الكراء", "الأكرية", "ابتدائي"),
    FileCode("1302", "الإفراغ", "الأكرية", "ابتدائي"),
    FileCode("1401", "العقار العادي", "العقار", "ابتدائي"),
    FileCode("1402", "العقار المحفظ", "العقار", "ابتدائي"),
    FileCode("1501", "نزاعات الشغل", "الاجتماعي", "ابتدائي"),
    FileCode("1502", "حوادث الشغل", "الاجتماعي", "ابتدائي"),
    FileCode("1606", "النفقة", "الأحوال الشخصية"),
    FileCode("1607", "التطليق", "الأحوال الشخصية"),
    FileCode("1614", "التذييل بالصيغة التنفيذية (أسرة)", "الأحوال الشخصية"),
    FileCode("1701", "طلب الأداء قضاء القرب", "قضاء القرب"),
    FileCode("6101", "البيوعات العقارية", "التنفيذ المدني"),
    FileCode("6150", "تنفيذ الأمر بالأداء", "تنفيذات مؤسسة الرئيس"),
    FileCode("6201", "مختلف قضايا التنفيذ المدني", "التنفيذ المدني"),
    FileCode("6203", "الحجز لدى الغير", "التنفيذ المدني"),
    FileCode("6204", "الإفراغات", "التنفيذ المدني"),
    FileCode("6205", "الحجز التنفيذي على منقول", "التنفيذ المدني"),
    FileCode("6206", "تنفيذ الأداءات", "التنفيذ المدني"),
    FileCode("6207", "تنفيذ الاسترجاعات", "التنفيذ المدني"),
    FileCode("6213", "التنفيذ التلقائي", "التنفيذ المدني"),
    FileCode("6250", "تنفيذ النفقة", "تنفيذات قضاء الأسرة"),
    FileCode("6305", "تنفيذ الأداءات (إنابات واردة)", "إنابات التنفيذ"),
    FileCode("6601", "تنفيذ الغرامات المالية", "تبليغات الأسرة وتنفيذ الغرامات", "ملاحظة: الرمز مكرر في المصدر"),
    FileCode("6601", "تبليغات النفقة", "تبليغات الأسرة وتنفيذ الغرامات", "ملاحظة: الرمز مكرر في المصدر"),
    FileCode("6701", "تبليغات المسؤولية التقصيرية", "تبليغات مختلف القضايا"),
    FileCode("6801", "تبليغات الحجز لدى الغير (إنابات واردة)", "تبليغات إنابات واردة"),
    FileCode("2101", "عادي تأديبي", "الجنحي العادي والتلبسي"),
    FileCode("2103", "تلبسي تأديبي اعتقال", "الجنحي العادي والتلبسي"),
    FileCode("2201", "جنحي أحداث ضبطي سراح", "الجنحي أحداث"),
    FileCode("2301", "التحقيق رشداء", "التحقيق"),
    FileCode("2401", "حوادث السير عادي تأديبي", "جنح وحوادث السير"),
    FileCode("2801", "جنحي عادي استئنافي", "الجنحي الاستئنافي"),
    FileCode("2901", "ملف شكاية مباشرة أمام المحكمة (قضايا الصحافة)", "الشكايات المباشرة"),
    FileCode("3101", "شكاية عادية", "الشكايات والمحاضر"),
    FileCode("3106", "شكاية شيك بدون مؤونة", "الشكايات والمحاضر"),
    FileCode("3201", "محضر عادي", "الشكايات والمحاضر"),
    FileCode("3213", "محضر محاربة المخدرات", "الشكايات والمحاضر"),
    FileCode("4101", "تنفيذ الغرامات المالية", "التنفيذ الزجري"),
    FileCode("4102", "تنفيذ العقوبات السالبة للحرية", "التنفيذ الزجري"),
    FileCode("7101", "القضايا الاستعجالية", "المحاكم الإدارية"),
    FileCode("7109", "تحصيل ديون الخزينة", "المحاكم الإدارية"),
    FileCode("7113", "المنازعات الضريبية", "المحاكم الإدارية"),
    FileCode("7205", "قضاء الإلغاء", "محاكم الاستئناف الإدارية"),
    FileCode("7213", "تحصيل ديون الخزينة", "محاكم الاستئناف الإدارية"),
    FileCode("7301", "التبليغ", "تبليغات المحاكم الإدارية"),
    FileCode("7401", "التنفيذ", "تنفيذ المحاكم الإدارية"),
    FileCode("7501", "التبليغ", "تبليغات المحاكم الإدارية"),
    FileCode("7601", "التنفيذ", "تنفيذ المحاكم الإدارية"),
    FileCode("8101", "الشعبة الاستعجالية (مؤسسة الرئيس)", "المحاكم التجارية"),
    FileCode("8201", "شعبة الموضوع", "المحاكم التجارية"),
    FileCode("8501", "تنفيذات", "تنفيذ المحاكم التجارية")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RumuzApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RumuzApp() {
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("كل التصنيفات") }
    var expanded by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<FileCode?>(null) }
    val categories = listOf("كل التصنيفات") + codes.map { it.category }.distinct().sorted()
    val filtered = codes.filter {
        (selectedCategory == "كل التصنيفات" || it.category == selectedCategory) &&
        (query.isBlank() || it.code.contains(query.trim()) || it.name.contains(query.trim(), true) || it.category.contains(query.trim(), true))
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Teal, background = Pale, surface = Color.White)) {
        Scaffold(containerColor = Pale, topBar = {
            Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 18.dp)) {
                Text("رموز الملفات", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                Text("دليل بحث سريع لرموز الملفات بالمحاكم المغربية", fontSize = 13.sp, color = Color(0xFFD8E6EE), textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("ابحث برقم الرمز أو اسم الملف…", textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()) },
                    trailingIcon = { Icon(Icons.Default.Search, contentDescription = "بحث", tint = Teal) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), shape = RoundedCornerShape(16.dp))
                Spacer(Modifier.height(10.dp))
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Tune, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(selectedCategory, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 420.dp)) {
                        categories.forEach { category -> DropdownMenuItem(text = { Text(category, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()) }, onClick = { selectedCategory = category; expanded = false }) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${filtered.size} نتيجة", color = Teal, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("الرمز  •  الوصف  •  التصنيف", color = Color.Gray, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد نتائج مطابقة. جرّب كلمة أو رمزاً آخر.", textAlign = TextAlign.Center, color = Color.Gray) }
                } else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                    items(filtered) { item ->
                        Card(modifier = Modifier.fillMaxWidth().clickable { selected = item }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                    Text(item.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, textAlign = TextAlign.End, color = Navy)
                                    Spacer(Modifier.height(5.dp))
                                    Text(item.category + if (item.level.isNotBlank() && !item.level.startsWith("ملاحظة")) " • ${item.level}" else "", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.End)
                                    if (item.level.startsWith("ملاحظة")) Text(item.level, color = Color(0xFF9A5A00), fontSize = 11.sp, textAlign = TextAlign.End)
                                }
                                Spacer(Modifier.width(12.dp))
                                Box(Modifier.background(Teal.copy(alpha = .11f), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
                                    Text(item.code, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Teal)
                                }
                            }
                        }
                    }
                }
                Text("مصدر أولي: mandili.net/law/25925 • راجع التصنيف المعتمد بمحكمتك قبل الاستعمال الرسمي", fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 3.dp))
                Text("من إعداد أمين نوحو", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Navy, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
            }
        }
        selected?.let { item ->
            AlertDialog(onDismissRequest = { selected = null }, confirmButton = { TextButton(onClick = { selected = null }) { Text("إغلاق") } },
                title = { Text("تفاصيل الرمز ${item.code}", textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()) },
                text = { Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) {
                    Text(item.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp)); Text("التصنيف: ${item.category}", textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    if (item.level.isNotBlank()) Text(item.level, color = Color(0xFF9A5A00), textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                } })
        }
    }
}
